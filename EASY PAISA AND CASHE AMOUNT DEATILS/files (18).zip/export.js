/**
 * export.js
 * -----------------------------------------------------------
 * Exports the currently visible (filtered) dataset to a real,
 * professionally styled .xlsx file using ExcelJS:
 *   - Branded green/teal header row (bold, white text)
 *   - Borders on every cell
 *   - Currency formatting on the Amount column
 *   - Auto-sized columns + frozen header row
 *   - Alternating row shading for readability
 *
 * Also hardened against bad/legacy data: every field is safely
 * coerced to a string/number before use, so a stray number or
 * null value (e.g. transactionId saved as a number) can never
 * crash the export again.
 * -----------------------------------------------------------
 */

const ExportEngine = (function () {

    function safeStr(v) {
        if (v === null || v === undefined) return "";
        return String(v).trim();
    }

    function safeNum(v) {
        const n = Number(v);
        return Number.isFinite(n) ? n : 0;
    }

    async function exportToExcel() {
        if (typeof ExcelJS === "undefined") {
            alert("Excel engine (ExcelJS) not loaded — check your internet connection.");
            return;
        }

        let dataset;
        try {
            dataset = SearchFilter.getFiltered();
        } catch (err) {
            console.error("SearchFilter.getFiltered() failed, falling back to full ledger:", err);
            dataset = await LedgerDB.getAllEntries();
        }

        if (!dataset || dataset.length === 0) {
            alert("No records to export in the current view.");
            return;
        }

        const rows = dataset.map((r, i) => ({
            "#": i + 1,
            "Date": safeStr(r.date),
            "Time": safeStr(r.time),
            "Client / Description": safeStr(r.name),
            "Account": safeStr(r.account),
            "City / Zone": safeStr(r.city),
            "Sender": safeStr(r.sender),
            "Transaction ID": safeStr(r.transactionId),
            "Customer ID": safeStr(r.customerId),
            "Status": safeStr(r.status),
            "Amount (Rs.)": safeNum(r.amount)
        }));

        try {
            const workbook = new ExcelJS.Workbook();
            workbook.creator = "AirTouch Wireless ISP Network";
            workbook.created = new Date();

            const sheet = workbook.addWorksheet("Ledger", {
                views: [{ state: "frozen", ySplit: 1 }]
            });

            const columns = [
                { header: "#", key: "num", width: 6 },
                { header: "Date", key: "date", width: 13 },
                { header: "Time", key: "time", width: 11 },
                { header: "Client / Description", key: "name", width: 26 },
                { header: "Account", key: "account", width: 16 },
                { header: "City / Zone", key: "city", width: 16 },
                { header: "Sender", key: "sender", width: 16 },
                { header: "Transaction ID", key: "txnId", width: 20 },
                { header: "Customer ID", key: "custId", width: 16 },
                { header: "Status", key: "status", width: 14 },
                { header: "Amount (Rs.)", key: "amount", width: 16 }
            ];
            sheet.columns = columns;

            rows.forEach((r) => {
                sheet.addRow({
                    num: r["#"],
                    date: r["Date"],
                    time: r["Time"],
                    name: r["Client / Description"],
                    account: r["Account"],
                    city: r["City / Zone"],
                    sender: r["Sender"],
                    txnId: r["Transaction ID"],
                    custId: r["Customer ID"],
                    status: r["Status"],
                    amount: r["Amount (Rs.)"]
                });
            });

            const headerRow = sheet.getRow(1);
            headerRow.height = 24;
            headerRow.eachCell((cell) => {
                cell.font = { bold: true, color: { argb: "FFFFFFFF" }, size: 11 };
                cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF059669" } };
                cell.alignment = { vertical: "middle", horizontal: "center" };
                cell.border = {
                    top: { style: "thin", color: { argb: "FF0D9488" } },
                    left: { style: "thin", color: { argb: "FF0D9488" } },
                    bottom: { style: "thin", color: { argb: "FF0D9488" } },
                    right: { style: "thin", color: { argb: "FF0D9488" } }
                };
            });

            for (let i = 2; i <= sheet.rowCount; i++) {
                const row = sheet.getRow(i);
                const isEven = i % 2 === 0;
                row.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                    cell.border = {
                        top: { style: "thin", color: { argb: "FFE2E8F0" } },
                        left: { style: "thin", color: { argb: "FFE2E8F0" } },
                        bottom: { style: "thin", color: { argb: "FFE2E8F0" } },
                        right: { style: "thin", color: { argb: "FFE2E8F0" } }
                    };
                    cell.font = { size: 10.5, color: { argb: "FF1E293B" } };
                    cell.alignment = { vertical: "middle" };
                    if (isEven) {
                        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF0FDF9" } };
                    }
                    if (colNumber === columns.length) {
                        cell.numFmt = '"Rs. "#,##0.00';
                        cell.alignment = { vertical: "middle", horizontal: "right" };
                        cell.font = { size: 10.5, bold: true, color: { argb: "FF047857" } };
                    }
                });
            }

            sheet.autoFilter = {
                from: { row: 1, column: 1 },
                to: { row: 1, column: columns.length }
            };

            const buffer = await workbook.xlsx.writeBuffer();
            const blob = new Blob([buffer], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            });
            const stamp = new Date().toISOString().slice(0, 10);
            const url = URL.createObjectURL(blob);
            const link = document.createElement("a");
            link.href = url;
            link.download = `AirTouch_Ledger_${stamp}.xlsx`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);

        } catch (err) {
            console.error("Export failed:", err);
            alert("Export fail ho gaya. Wajah: " + err.message);
        }
    }

    return { exportToExcel };
})();
